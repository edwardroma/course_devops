from resources import int_check, pause
import secrets


# 2. MemoryGame.py
# The purpose of memory game is to display an amount of random numbers to the users for 0.7
# seconds and then prompt them from the user for the numbers that he remember. If he was right
# with all the numbers the user will win otherwise he will lose.


class GameMemory:
    pause("to start a 'Memory Game'")
    def __init__(self):
        self.result = ""
        self.difficulty = ""
#        self.action = action
        self.sequence1 = ""
        self.sequence2 = ""

    # Properties 1. Difficulty
    def set_difficulty(self):
        self.difficulty = int_check("to define the difficulty level")

    # Methods
    # 1. generate_sequence - Will generate a list of random numbers between 1 and 101. The list
    # length will be difficulty.
    def generate_sequence(self):
        self.sequence1 = []
        while len(self.sequence1) < int(self.difficulty):
            self.sequence1.append(secrets.choice(range(1, 101)))
        print("Here is your sequence for testing purposes:")
        for x, y in enumerate(self.sequence1):
            print(y, end=" ")
            if x % 5 == 4:
                print("")
        print()
        return self.sequence1

    # 2. get_list_from_user - Will return a list of numbers prompted from the user. The list length
    # will be in the size of difficulty.
    def get_list_from_user(self):
        self.sequence2 = []
        while len(self.sequence2) < int(self.difficulty):
            x = int_check("to form your own list")
            self.sequence2.append(x)
            for x, y in enumerate(self.sequence2):
            # print(y, end=", ")
                if x % 5 == 4:
                    pass
        print("Your list is: ", self.sequence2)
        return self.sequence2

    # 3. is_list_equal - A function to compare two lists if they are equal. The function will return
    # True / False.
    def is_list_equal(self):
        pause("to compare the lists")
        sequence1 = sorted(self.sequence1)
        sequence2 = sorted(self.sequence2)
        if sequence1 == sequence2:
            self.result = "True! - You won!!!"
        else:
            self.result = "False - You lost ((( ..."
        return self.result

# 4. play - Will call the functions above and play the game. Will return True / False if the user
# lost or won.

    def play(self):
        action = "go"
        while action == "go":
            self.set_difficulty()
            self.generate_sequence()
            self.get_list_from_user()
            self.is_list_equal()
            print(self.result)
            print("Wanna try again? (NB: We'll take 'go' -  for 'Yes', and anything else for 'No)")
            action = input("So, what would you say? :")
        else:
            print("Thanks for playing with us. See you next game!) ")
            exit()
