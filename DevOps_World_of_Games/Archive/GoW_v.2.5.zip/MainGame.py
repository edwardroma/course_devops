from Live import welcome, load_game

print(welcome("Buddy"))
# Function Update
load_game()
