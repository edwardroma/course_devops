from resources import int_check, pause
import random

# 3. CurrencyRouletteGame.py
# This game will use the free currency api to get the current exchange rate from USD to ILS, will
# generate a new random number between 1-100 a will ask the user what he thinks is the value of
# the generated number from USD to ILS, depending on the user’s difficulty his answer will be
# correct if the guessed value is between the interval surrounding the correct answer

class GameCurrency:
    pause("to start a 'Currency Game'")
    def __init__(self):
        # Properties 1. Difficulty
        self.difficulty = ""
        self.shekel_rate = ""
        self.limit1 = ""
        self.limit2 = ""
        self.guess = ""
        self.result = ""
    # Properties. 1. Difficulty
    def set_difficulty(self):
        self.difficulty = int_check("to define the difficulty level - up to 5")
    # Methods
    # 1. get_money_interval - Will
    # get the current currency rate from USD to ILS and will
    def get_shekel_rate(self):
        import requests
        url = "https://v6.exchangerate-api.com/v6/617730a39f8a17d511fe6315/latest/USD"
        rates = requests.get(url)
        self.shekel_rate = rates.json()["conversion_rates"]["ILS"]
        return self.shekel_rate
    # generate an interval as follows:
    # a. for given difficulty d, and total value of money t the interval will be:
    # (t - (5 - d), t + (5 - d))
    # def get_money_interval(self):
    # 2. get_guess_from_user - A method to prompt a guess from the user to enter a guess of
    # value to a given amount of USD
    def get_guess_from_user(self):
        random_number = int(random.randint(1, 10))
        total = self.shekel_rate * random_number
        self.limit1 = int(total) - (5 + int(self.difficulty))
        if self.limit1 < 0:
            self.limit1 = 0
        else:
            pass
        print("self.limit1", self.limit1)
        self.limit2 = int(total) + (5 + int(self.difficulty))
        print("self.limit2", self.limit2)
        print("FYI, the correct answer for testing purposes is: ", total)
        self.guess = int_check(f"gimme your shekel amount for {random_number} dollars")
    # Check the guess against the interval
    def is_get_correct(self):
        pause("to compare the lists")
        if self.guess in range(int(self.limit1), int(self.limit2)):
            self.result = "True! - You won!!!"
        else:
            self.result = "False - You lost ((( ..."
        return self.result
#     # 3. play - Will call the functions above and play the game. Will return True / False if the user
#     # lost or won.
    def play(self):
        action = "go"
        while action == "go":
            self.set_difficulty()
            self.get_shekel_rate()
            self.get_guess_from_user()
            self.is_get_correct()
            print(self.result)
            print("Wanna try again? (NB: We'll take 'go' -  for 'Yes', and anything else for 'No)")
            action = input("So, what would you say? :")
        else:
            print("Thanks for playing with us. See you next game!) ")
            exit()
