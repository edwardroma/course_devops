from resources import pause, int_check, take_ext_turn_int
import secrets

# 1. GuessGame.py. The purpose of guess game is to start a new game,
# cast a random number between 1 to a variable called difficulty.
# The game will get a number input from the

class GameGuess:
    pause("to start a 'Guess Game'")
    def __init__(self, difficulty_ext):
        self.guess_from_user = ""
        self.secret_number = ""
        self.result = ""
        self.difficulty_ext = difficulty_ext
        self.difficulty_int = ""
    # def does_difficulty_ext_exist(self):
    #     if self.difficulty_ext != "":
    #         self.difficulty_int = self.difficulty_ext
    #         self.difficulty_ext = ""
    #     else:
    #         self.set_difficulty_int()
    #     return self.difficulty_int
    # Methods
    # 1. generate_number - Will generate number between 1 to difficulty and save it to
    # secret_number.
    def set_difficulty_int(self):
        self.difficulty_int = int_check("to define the difficulty level")
    def generate_number(self):
        pause("to generate your secret number")
        self.secret_number = secrets.choice(range(1, int(self.difficulty_int)))
        print("shh! just between you and me: your secret number is: ", self.secret_number)
        return self.secret_number
    # 2. get_guess_from_user - Will prompt the user for a number between 1 to difficulty and
    # return the number.
    def get_guess_from_user(self):
        self.guess_from_user = int_check("to try and guess the secret number")
        return self.guess_from_user
    # 3. compare_results - Will compare the secret generated number to the one prompted
    # by the get_guess_from_user.
    def compare_results(self):
        pause("to compare the numbers")
        self.result = ""
        if self.secret_number == self.guess_from_user:
            self.result = "True! - You won!!!"
        else:
            self.result = "False - You lost ((( ..."
        return self.result
    # 4. play - Will call the functions above and play the game. Will return True / False if the user
    # lost or won.
    def play(self):
        action = "go"
        self.difficulty_ext, self.difficulty_int = take_ext_turn_int(self.difficulty_ext, self.difficulty_int)
        while action == "go":
            self.generate_number()
            self.get_guess_from_user()
            self.compare_results()
            print(self.result)
            print("Wanna try again? (NB: We'll take 'go' -  for 'Yes', and anything else - for 'No)")
            action = input("So, what would you say? :")
        else:
            print("Thanks for playing with us. See you next game!) ")
            exit()
