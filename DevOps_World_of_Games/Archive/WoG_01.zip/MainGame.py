from Live import welcome, load_game

print(welcome("Buddy"))
load_game()