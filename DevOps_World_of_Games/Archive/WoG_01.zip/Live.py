from _functions.gen_functons import ich
def welcome(name):
#    name = input("Please give me your name: ")
    print(f"Hello {name} and welcome to the World of Games (WoG).\n"
          f"Here you can find many cool games to play.")


def load_game():
    print("Right now we have for you:\n"
          "        1. Memory Game - a sequence of numbers will appear for 1 second "
          "and you have to guess it back.\n"
          "        2. Guess Game - guess a number and see if you choose like the "
          "computer.\n"
          "        3. Currency Roulette - try and guess the value of a random amount "
          "of USD in ILS.")
    game_num = 0
    while True:
        try:
            game_num = int(input('Please enter your game number (1, 2, or 3): '))
            if game_num > 3 or game_num < 1:
                print('Please Choose 1, 2, or 3:')
                continue
            else:
                print(f'You have chosen game # {game_num}')
                break
        except ValueError:
            print(f"Your input does look like an integer. Let's try again...")
    game_dif = 0
    while True:
        try:
            game_dif = int(input('Please enter your game number (between 1 and 5): '))
            if game_dif > 5 or game_num < 1:
                print('Please Choose 1-5:')
                continue
            else:
                print(f'You have chosen game difficulty level # {game_dif}')
                break
        except ValueError:
            print(f"Your input does look like an integer. Let's try again...")
    return game_num, game_dif
