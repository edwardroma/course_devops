# Create a list automatically

def create_list_auto(txt):
    lst_a = []
    count = int(ich(txt))
    for i in range(count):
        lst_a.append(i)
    return lst_a
