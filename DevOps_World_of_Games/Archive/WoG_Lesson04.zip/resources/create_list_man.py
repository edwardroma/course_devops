# Create a list manually

def create_list_man(txt):
    print("NB: 'Empty' input terminates the list.")
    lst_m = []
    mm = 1
    while mm != "":
        mm = input("Please give a str: ")
        lst_m.append(mm)
    else:
        pass
    lst_m.pop(-1)
    return lst_m
