# This is the function to nake sure that the input is an integer.

def int_check(to_do):
    while True:
        input_string = ""
        try:
            input_string = input(f"Please give an integer {to_do}: ")
            input_integer = int(input_string)
            break
        except ValueError:
            print(f"Your input '{input_string}' does look like an integer. Let's try again...")
    return input_integer
