# This is a function for task breaking, for the sake of readability

def pause(to_do):
    input(f'Press \'ENTER\' {to_do}: ')
