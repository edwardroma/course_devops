from Live import welcome, load_game

if __name__ == "__main__":
    print(welcome("Edward"))
    load_game()
