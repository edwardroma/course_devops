def welcome(name):
    # name = input("Please give me your name: ")
    return f"Hello {name} and welcome to the World of Games (WoG).\nHere you can find many cool games to play."


# 1. Change the function load_game() from the previous document that after it will get the
# user’s game of choice and level of difficulty, it will start a new function of the


def load_game():
    from GuessGame import GuessGame
    from MemoryGame import MemoryGame
    from CurrencyGame import CurrencyGame
    print("Right now we have for you:\n"
          "        1. Memory Game - a sequence of numbers will appear for 1 second "
          "and you have to guess it back.\n"
          "        2. Guess Game - guess a number and see if you choose like the "
          "computer.\n"
          "        3. Currency Roulette - try and guess the value of a random amount "
          "of USD in ILS.")
    # game_num = 0
    while True:
        try:
            game_num = int(input('Please enter your game number (1, 2, or 3): '))
            if game_num > 3 or game_num < 1:
                print('Please Choose 1 (Memory Game), 2 (Guess Game), or 3 (Currency Roulette):')
                print(game_num)
                continue
            else:
                print(f'You have chosen game # {game_num}')
                break
        except ValueError:
            print(f"Your input does look like an integer. Let's try again...")
    # game_dif = 0
    while True:
        try:
            game_dif = int(input('Please enter your game difficulty level (between 1 and 5): '))
            if game_dif > 5 or game_dif < 1:
                print('Please Choose 1-5:')
                continue
            else:
                print(f'You have chosen game difficulty level # {game_dif}')
                print(game_num)
                break
        except ValueError:
            print(f"Your input does look like an integer. Let's try again...")

    game_num_global, game_dif_global = load_game()

    guess_game1 = GuessGame
    memory_game1 = MemoryGame
    currency_game1 = CurrencyGame

    if game_num_global == 1:
        guess_game1(game_dif_global)
    elif game_num_global == 2:
        memory_game1(game_dif_global)
    elif game_num_global == 3:
        currency_game1(game_dif_global)

    return game_num_global, game_dif_global
# corresponding game with the given difficulty. For example: If a user will choose the first
# option in load_game() function with difficulty 3, it will call the play() function from the
# module MemoryGame with difficulty of 3.


if __name__ == "_main_":
    welcome("")
    load_game()
